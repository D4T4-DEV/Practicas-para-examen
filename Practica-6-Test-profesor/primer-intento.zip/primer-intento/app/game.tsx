import React from 'react'
import GameScreen from '@/src/presentation/views/GameScreen'

const game = () => {
  return (
    <GameScreen/>
  )
}

export default game