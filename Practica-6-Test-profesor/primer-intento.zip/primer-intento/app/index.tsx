import React from 'react'
import HomeScreen from '@/src/presentation/views/HomeScreen'

const index = () => {
  return (
    <HomeScreen />
  )
}

export default index