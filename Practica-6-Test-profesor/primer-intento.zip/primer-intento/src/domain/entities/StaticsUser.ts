export interface PlayerStatics {
    incorrectAnswers: number;
    correctAnswers: number;
}