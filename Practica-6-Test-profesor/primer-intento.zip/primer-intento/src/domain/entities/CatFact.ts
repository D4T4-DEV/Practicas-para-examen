export interface CatFact {
    fact: string;
    isAFact: boolean;
}